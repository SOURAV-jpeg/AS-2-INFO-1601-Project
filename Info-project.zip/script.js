//initializing variables
var fbi='https://api.spoomnacular.com/recipies/findByIngredients?';

var ing='&ingredients=';
var key='apiKey=b864597e38f04ecdbe17f37388f51923';
var resultNum='&number=10';